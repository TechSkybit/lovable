import React from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Waves, 
  BarChart3, 
  Map, 
  AlertTriangle, 
  Settings, 
  User,
  Bell,
  Menu
} from 'lucide-react';

const Navigation = () => {
  return (
    <nav className="sticky top-0 z-50 w-full border-b border-border/40 glass-nav">
      <div className="container flex h-16 max-w-screen-2xl items-center px-4">
        {/* Logo & Brand */}
        <div className="mr-8 flex items-center space-x-3 hover-glow">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-ocean-gradient floating-slow">
            <Waves className="h-5 w-5 text-white" />
          </div>
          <div className="flex flex-col">
            <span className="text-lg font-semibold text-primary">INCOIS</span>
            <span className="text-xs text-muted-foreground">Ocean Hazard Platform</span>
          </div>
        </div>

        {/* Main Navigation */}
        <div className="flex flex-1 items-center justify-between">
          <div className="hidden md:flex items-center space-x-1">
            <Button variant="ghost" size="sm" className="text-primary hover:text-primary hover-lift focus-enhance">
              <Map className="mr-2 h-4 w-4" />
              Live Map
            </Button>
            <Button variant="ghost" size="sm" className="text-primary hover:text-primary hover-lift focus-enhance">
              <BarChart3 className="mr-2 h-4 w-4" />
              Analytics
            </Button>
            <Button variant="ghost" size="sm" className="text-primary hover:text-primary hover-lift focus-enhance relative">
              <AlertTriangle className="mr-2 h-4 w-4" />
              Reports
              <Badge variant="destructive" className="ml-1 h-5 w-5 rounded-full p-0 text-xs scale-pulse">
                3
              </Badge>
            </Button>
          </div>

          {/* Right Side Actions */}
          <div className="flex items-center space-x-3">
            {/* Emergency Report Button */}
            <Button variant="alert" size="sm" className="hidden sm:flex animate-pulse-glow hover-lift focus-enhance">
              <AlertTriangle className="mr-2 h-4 w-4" />
              Report Hazard
            </Button>

            {/* Notifications */}
            <Button variant="ghost" size="icon" className="relative hover-float focus-enhance">
              <Bell className="h-4 w-4" />
              <Badge variant="destructive" className="absolute -right-1 -top-1 h-4 w-4 rounded-full p-0 text-xs bounce-soft">
                2
              </Badge>
            </Button>

            {/* User Profile */}
            <Button variant="ghost" size="icon" className="hover-float focus-enhance">
              <User className="h-4 w-4" />
            </Button>

            {/* Mobile Menu */}
            <Button variant="ghost" size="icon" className="md:hidden hover-lift focus-enhance">
              <Menu className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;