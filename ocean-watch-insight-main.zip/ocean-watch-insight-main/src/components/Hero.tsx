import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  AlertTriangle, 
  Activity, 
  Users, 
  Shield,
  TrendingUp,
  MapPin,
  Zap,
  BarChart3
} from 'lucide-react';
import oceanHero from '@/assets/ocean-hero.jpg';

const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${oceanHero})` }}
      />
      <div className="absolute inset-0 bg-depth-gradient opacity-80" />
      
      {/* Wave Animation Overlay */}
      <div className="absolute inset-0 wave-pattern opacity-30" />

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 text-center">
        <div className="mx-auto max-w-4xl space-y-8">
          {/* Status Badge */}
          <Badge variant="outline" className="border-white/30 text-white bg-white/10 backdrop-blur-sm px-4 py-2">
            <Activity className="mr-2 h-4 w-4" />
            System Operational • Last Update: 2 min ago
          </Badge>

          {/* Main Heading */}
          <div className="space-y-4">
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white leading-tight">
              Ocean Hazard
              <span className="block bg-gradient-to-r from-secondary to-secondary-light bg-clip-text text-transparent">
                Monitoring & Response
              </span>
            </h1>
            <p className="text-xl md:text-2xl text-white/90 max-w-3xl mx-auto leading-relaxed">
              Advanced real-time monitoring and social media analytics for ocean hazards. 
              Protecting coastal communities through early detection and rapid response coordination.
            </p>
          </div>

          {/* Mission Statement */}
          <div className="mx-auto max-w-2xl">
            <Card variant="dashboard" className="text-left">
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    <Shield className="h-8 w-8 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-foreground mb-2">
                      INCOIS Mission
                    </h3>
                    <p className="text-muted-foreground">
                      Providing timely and accurate ocean information services for the safety of 
                      life and property at sea, coastal vulnerability assessment, and sustainable 
                      development of ocean resources.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button variant="ocean" size="xl" className="w-full sm:w-auto hover-lift focus-enhance stagger-1">
              <MapPin className="mr-2 h-5 w-5" />
              View Live Map
            </Button>
            <Button variant="alert" size="xl" className="w-full sm:w-auto hover-lift focus-enhance stagger-2">
              <AlertTriangle className="mr-2 h-5 w-5" />
              Report Emergency
            </Button>
            <Button variant="surface" size="xl" className="w-full sm:w-auto hover-lift focus-enhance stagger-3">
              <BarChart3 className="mr-2 h-5 w-5" />
              View Analytics
            </Button>
          </div>

          {/* Key Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
            <Card variant="dashboard" className="card-interactive stagger-1">
              <CardContent className="p-6 text-center">
                <div className="space-y-2">
                  <TrendingUp className="h-8 w-8 text-secondary mx-auto gentle-float" />
                  <div className="text-2xl font-bold text-foreground">24/7</div>
                  <p className="text-sm text-muted-foreground">Real-time Monitoring</p>
                </div>
              </CardContent>
            </Card>
            
            <Card variant="dashboard" className="card-interactive stagger-2">
              <CardContent className="p-6 text-center">
                <div className="space-y-2">
                  <Users className="h-8 w-8 text-accent-dark mx-auto floating-delayed" />
                  <div className="text-2xl font-bold text-foreground">10,000+</div>
                  <p className="text-sm text-muted-foreground">Active Users</p>
                </div>
              </CardContent>
            </Card>
            
            <Card variant="dashboard" className="card-interactive stagger-3">
              <CardContent className="p-6 text-center">
                <div className="space-y-2">
                  <Zap className="h-8 w-8 text-primary mx-auto rotate-slow" />
                  <div className="text-2xl font-bold text-foreground">99.9%</div>
                  <p className="text-sm text-muted-foreground">System Uptime</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Floating Elements */}
      <div className="absolute bottom-8 left-8 hidden lg:block">
        <Card variant="dashboard" className="p-4 glass-card hover-float">
          <div className="flex items-center space-x-3">
            <div className="h-3 w-3 rounded-full bg-accent scale-pulse" />
            <span className="text-sm text-muted-foreground">Monitoring 847 sensors</span>
          </div>
        </Card>
      </div>

      <div className="absolute bottom-8 right-8 hidden lg:block">
        <Card variant="dashboard" className="p-4 glass-card hover-float">
          <div className="flex items-center space-x-3">
            <Badge variant="outline" className="status-active gentle-float">Active</Badge>
            <span className="text-sm text-muted-foreground">All systems operational</span>
          </div>
        </Card>
      </div>
    </section>
  );
};

export default Hero;