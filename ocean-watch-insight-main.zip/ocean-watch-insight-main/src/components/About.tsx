import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Shield, 
  Users, 
  Globe, 
  Zap, 
  Target,
  Award,
  BookOpen,
  Phone
} from 'lucide-react';

const About = () => {
  const services = [
    {
      icon: Shield,
      title: 'Tsunami Warning System',
      description: 'Real-time tsunami detection and early warning services for the Indian Ocean region.',
      features: ['24/7 Monitoring', 'Multi-sensor Network', 'Rapid Alert Distribution']
    },
    {
      icon: Globe,
      title: 'Ocean State Forecasting',
      description: 'Comprehensive ocean condition forecasting and marine weather predictions.',
      features: ['Wave Height Prediction', 'Current Analysis', 'Temperature Mapping']
    },
    {
      icon: Zap,
      title: 'Emergency Response',
      description: 'Coordinated emergency response and crisis management support services.',
      features: ['Incident Management', 'Resource Coordination', 'Public Communication']
    },
    {
      icon: Users,
      title: 'Community Engagement',
      description: 'Public education and community preparedness programs for coastal safety.',
      features: ['Training Programs', 'Awareness Campaigns', 'Stakeholder Engagement']
    }
  ];

  const achievements = [
    { number: '15+', label: 'Years of Service' },
    { number: '847', label: 'Monitoring Stations' },
    { number: '12', label: 'Countries Served' },
    { number: '99.9%', label: 'System Reliability' }
  ];

  return (
    <section className="py-16 bg-muted/30">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <Badge variant="outline" className="mb-4">About INCOIS</Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Protecting Lives Through Ocean Science
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            The Indian National Centre for Ocean Information Services (INCOIS) is an autonomous 
            organization under the Ministry of Earth Sciences, Government of India. We provide 
            ocean information and advisory services to society, industry, government agencies 
            and the scientific community.
          </p>
        </div>

        {/* Mission & Vision */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
          <Card variant="ocean">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Target className="mr-3 h-6 w-6 text-primary" />
                Our Mission
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed">
                To provide the best possible ocean information and advisory services to society, 
                industry, government agencies and the scientific community through sustained ocean 
                observations and constant improvement in the prediction capabilities for the safety 
                of life and property at sea, coastal vulnerability assessment, sustainable development 
                of ocean resources and conservation of marine environment.
              </p>
            </CardContent>
          </Card>

          <Card variant="ocean">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Award className="mr-3 h-6 w-6 text-secondary" />
                Our Vision
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed">
                To be recognized as the premier ocean information and services provider in the 
                Indian Ocean region, fostering blue economy development while ensuring ocean 
                sustainability through innovative science, technology, and community engagement.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Key Services */}
        <div className="mb-16">
          <div className="text-center mb-12">
            <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
              Key Services & Capabilities
            </h3>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Comprehensive ocean monitoring and information services powered by advanced 
              technology and scientific expertise.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {services.map((service, index) => {
              const IconComponent = service.icon;
              return (
                <Card key={index} variant="dashboard" className={`card-interactive stagger-${(index % 4) + 1}`}>
                  <CardHeader>
                    <CardTitle className="flex items-start space-x-3">
                      <div className="flex-shrink-0 p-2 bg-primary/10 rounded-lg hover-float">
                        <IconComponent className="h-6 w-6 text-primary gentle-float" />
                      </div>
                      <div>
                        <h4 className="text-xl font-semibold text-foreground">{service.title}</h4>
                        <p className="text-sm text-muted-foreground mt-1">{service.description}</p>
                      </div>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {service.features.map((feature, featureIndex) => (
                        <div key={featureIndex} className="flex items-center space-x-2 hover-lift transition-all duration-200">
                          <div className="h-1.5 w-1.5 rounded-full bg-accent-dark pulse-subtle" />
                          <span className="text-sm text-muted-foreground">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Achievements */}
        <div className="mb-16">
          <div className="text-center mb-12">
            <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
              Our Impact & Achievements
            </h3>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {achievements.map((achievement, index) => (
              <Card key={index} variant="surface" className={`text-center card-interactive stagger-${(index % 4) + 1}`}>
                <CardContent className="p-6">
                  <div className="text-3xl md:text-4xl font-bold text-primary mb-2 scale-pulse">
                    {achievement.number}
                  </div>
                  <div className="text-sm text-muted-foreground font-medium">
                    {achievement.label}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Contact & Learn More */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card variant="ocean">
            <CardHeader>
              <CardTitle className="flex items-center">
                <BookOpen className="mr-3 h-6 w-6 text-secondary" />
                Educational Resources
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-6">
                Access comprehensive educational materials about ocean science, tsunami preparedness, 
                and marine safety protocols.
              </p>
              <div className="space-y-3">
                <Button variant="surface" className="w-full justify-start">
                  <BookOpen className="mr-2 h-4 w-4" />
                  Tsunami Safety Guide
                </Button>
                <Button variant="surface" className="w-full justify-start">
                  <Globe className="mr-2 h-4 w-4" />
                  Ocean Science Portal
                </Button>
                <Button variant="surface" className="w-full justify-start">
                  <Users className="mr-2 h-4 w-4" />
                  Community Programs
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card variant="ocean">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Phone className="mr-3 h-6 w-6 text-primary" />
                Contact & Support
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-6">
                Get in touch with our experts for technical support, partnership opportunities, 
                or emergency assistance.
              </p>
              <div className="space-y-4">
                <div className="flex items-center space-x-3 text-sm">
                  <div className="h-2 w-2 rounded-full bg-accent-dark" />
                  <span className="text-muted-foreground">24/7 Emergency Hotline</span>
                </div>
                <div className="flex items-center space-x-3 text-sm">
                  <div className="h-2 w-2 rounded-full bg-accent-dark" />
                  <span className="text-muted-foreground">Technical Support Team</span>
                </div>
                <div className="flex items-center space-x-3 text-sm">
                  <div className="h-2 w-2 rounded-full bg-accent-dark" />
                  <span className="text-muted-foreground">Research Partnerships</span>
                </div>
                <Button variant="ocean" className="w-full mt-4">
                  <Phone className="mr-2 h-4 w-4" />
                  Contact INCOIS
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default About;