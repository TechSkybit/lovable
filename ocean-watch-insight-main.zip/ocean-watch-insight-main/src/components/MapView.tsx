import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Map, 
  Layers, 
  Filter, 
  ZoomIn, 
  ZoomOut,
  AlertTriangle,
  Activity,
  MapPin,
  Settings
} from 'lucide-react';

const MapView = () => {
  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Interactive Hazard Map
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Real-time visualization of ocean hazards, sensor data, and emergency reports 
            across the Indian Ocean region.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Map Controls */}
          <Card variant="ocean" className="lg:col-span-1 card-interactive">
            <CardHeader>
              <CardTitle className="flex items-center text-lg">
                <Layers className="mr-2 h-5 w-5 gentle-float" />
                Map Controls
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Layer Controls */}
              <div>
                <h4 className="text-sm font-medium text-foreground mb-3">Data Layers</h4>
                <div className="space-y-2">
                  <label className="flex items-center space-x-2 cursor-pointer hover-lift transition-all duration-200">
                    <input type="checkbox" className="rounded focus-enhance" defaultChecked />
                    <span className="text-sm">Hazard Alerts</span>
                    <Badge variant="destructive" className="ml-auto scale-pulse">23</Badge>
                  </label>
                  <label className="flex items-center space-x-2 cursor-pointer hover-lift transition-all duration-200">
                    <input type="checkbox" className="rounded focus-enhance" defaultChecked />
                    <span className="text-sm">Sensor Network</span>
                    <Badge variant="outline" className="ml-auto pulse-subtle">847</Badge>
                  </label>
                  <label className="flex items-center space-x-2 cursor-pointer hover-lift transition-all duration-200">
                    <input type="checkbox" className="rounded focus-enhance" />
                    <span className="text-sm">Social Reports</span>
                    <Badge variant="outline" className="ml-auto gentle-float">156</Badge>
                  </label>
                  <label className="flex items-center space-x-2 cursor-pointer hover-lift transition-all duration-200">
                    <input type="checkbox" className="rounded focus-enhance" />
                    <span className="text-sm">Weather Data</span>
                  </label>
                </div>
              </div>

              {/* Filter Controls */}
              <div>
                <h4 className="text-sm font-medium text-foreground mb-3">Filters</h4>
                <div className="space-y-2">
                  <Button variant="outline" size="sm" className="w-full justify-start hover-lift focus-enhance">
                    <Filter className="mr-2 h-4 w-4 rotate-slow" />
                    Severity Level
                  </Button>
                  <Button variant="outline" size="sm" className="w-full justify-start hover-lift focus-enhance">
                    <MapPin className="mr-2 h-4 w-4 bounce-soft" />
                    Region
                  </Button>
                  <Button variant="outline" size="sm" className="w-full justify-start hover-lift focus-enhance">
                    <Activity className="mr-2 h-4 w-4 pulse-subtle" />
                    Time Range
                  </Button>
                </div>
              </div>

              {/* Zoom Controls */}
              <div>
                <h4 className="text-sm font-medium text-foreground mb-3">Navigation</h4>
                <div className="flex space-x-2">
                  <Button variant="surface" size="sm" className="flex-1 hover-lift focus-enhance">
                    <ZoomIn className="h-4 w-4" />
                  </Button>
                  <Button variant="surface" size="sm" className="flex-1 hover-lift focus-enhance">
                    <ZoomOut className="h-4 w-4" />
                  </Button>
                  <Button variant="surface" size="sm" className="flex-1 hover-lift focus-enhance">
                    <Settings className="h-4 w-4 rotate-slow" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Main Map Area */}
          <Card variant="dashboard" className="lg:col-span-3 card-interactive">
            <CardContent className="p-0">
              <div className="relative h-96 lg:h-[600px] bg-accent/10 rounded-lg overflow-hidden">
                {/* Map Placeholder */}
                <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-primary/5 to-accent/10">
                  <div className="text-center space-y-4">
                    <Map className="h-16 w-16 text-primary mx-auto gentle-float" />
                    <div>
                      <h3 className="text-xl font-semibold text-foreground">Interactive Map Loading...</h3>
                      <p className="text-muted-foreground">
                        Map visualization with real-time hazard data will be displayed here
                      </p>
                    </div>
                    <Button variant="ocean" className="hover-lift focus-enhance">
                      Load Map Interface
                    </Button>
                  </div>
                </div>

                {/* Sample Overlay Elements */}
                <div className="absolute top-4 left-4">
                  <Card variant="alert" className="p-3 hover-float">
                    <div className="flex items-center space-x-2">
                      <AlertTriangle className="h-4 w-4 text-destructive scale-pulse" />
                      <span className="text-sm font-medium">Tsunami Warning - Bay of Bengal</span>
                    </div>
                  </Card>
                </div>

                <div className="absolute bottom-4 right-4">
                  <Card variant="dashboard" className="p-3 glass-card hover-float">
                    <div className="flex items-center space-x-2 text-sm">
                      <Activity className="h-4 w-4 text-accent-dark pulse-subtle" />
                      <span>847 sensors active</span>
                    </div>
                  </Card>
                </div>

                {/* Legend */}
                <div className="absolute bottom-4 left-4">
                  <Card variant="dashboard" className="p-4 glass-card hover-lift">
                    <h4 className="text-sm font-semibold text-foreground mb-3">Legend</h4>
                    <div className="space-y-2 text-xs">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 rounded-full bg-destructive scale-pulse" />
                        <span>High Risk Areas</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 rounded-full bg-secondary gentle-float" />
                        <span>Medium Risk Areas</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 rounded-full bg-accent pulse-subtle" />
                        <span>Monitoring Zones</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 rounded bg-primary bounce-soft" />
                        <span>Sensor Stations</span>
                      </div>
                    </div>
                  </Card>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Map Statistics */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-5 gap-4">
          <Card variant="ocean" className="card-interactive stagger-1">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-destructive scale-pulse">23</div>
              <div className="text-xs text-muted-foreground">Active Alerts</div>
            </CardContent>
          </Card>
          
          <Card variant="ocean" className="card-interactive stagger-2">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-primary gentle-float">847</div>
              <div className="text-xs text-muted-foreground">Sensors Online</div>
            </CardContent>
          </Card>
          
          <Card variant="ocean" className="card-interactive stagger-3">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-secondary bounce-soft">156</div>
              <div className="text-xs text-muted-foreground">User Reports</div>
            </CardContent>
          </Card>
          
          <Card variant="ocean" className="card-interactive stagger-4">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-accent-dark pulse-subtle">12</div>
              <div className="text-xs text-muted-foreground">Regions Covered</div>
            </CardContent>
          </Card>
          
          <Card variant="ocean" className="card-interactive stagger-1">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-accent-dark rotate-slow">99.9%</div>
              <div className="text-xs text-muted-foreground">System Uptime</div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default MapView;