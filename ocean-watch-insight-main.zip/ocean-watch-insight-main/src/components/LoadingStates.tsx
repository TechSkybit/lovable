import React from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';

const LoadingStates = () => {
  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Loading States & Animations
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Demonstration of various loading states and animation effects used throughout the platform.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Shimmer Loading */}
          <Card variant="dashboard" className="card-interactive">
            <CardHeader>
              <h3 className="text-xl font-semibold">Shimmer Loading Effect</h3>
              <p className="text-sm text-muted-foreground">Smooth loading animation for content placeholders</p>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="h-4 bg-muted rounded shimmer"></div>
                <div className="h-4 bg-muted rounded shimmer w-3/4"></div>
                <div className="h-4 bg-muted rounded shimmer w-1/2"></div>
              </div>
            </CardContent>
          </Card>

          {/* Skeleton Loading */}
          <Card variant="dashboard" className="card-interactive">
            <CardHeader>
              <h3 className="text-xl font-semibold">Skeleton Placeholders</h3>
              <p className="text-sm text-muted-foreground">Structured content loading indicators</p>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Skeleton className="h-12 w-12 rounded-full" />
                <div className="space-y-2">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-4/5" />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Floating Animations */}
          <Card variant="ocean" className="card-interactive">
            <CardHeader>
              <h3 className="text-xl font-semibold text-white">Floating Elements</h3>
              <p className="text-sm text-white/80">Various floating animation speeds and patterns</p>
            </CardHeader>
            <CardContent>
              <div className="flex justify-around items-center h-20">
                <div className="w-8 h-8 bg-white/20 rounded-full floating-slow"></div>
                <div className="w-8 h-8 bg-white/30 rounded-full floating-fast"></div>
                <div className="w-8 h-8 bg-white/40 rounded-full floating-delayed"></div>
              </div>
            </CardContent>
          </Card>

          {/* Interactive Buttons */}
          <Card variant="surface" className="card-interactive">
            <CardHeader>
              <h3 className="text-xl font-semibold">Interactive Elements</h3>
              <p className="text-sm text-muted-foreground">Hover effects and micro-interactions</p>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <Button variant="ocean" className="w-full hover-lift">
                  Ocean Button (Lift Effect)
                </Button>
                <Button variant="alert" className="w-full hover-glow">
                  Alert Button (Glow Effect)
                </Button>
                <Button variant="surface" className="w-full hover-float">
                  Surface Button (Float Effect)
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Pulse Animations */}
          <Card variant="dashboard" className="card-interactive">
            <CardHeader>
              <h3 className="text-xl font-semibold">Pulse & Scale Effects</h3>
              <p className="text-sm text-muted-foreground">Attention-drawing animations for alerts</p>
            </CardHeader>
            <CardContent>
              <div className="flex justify-around items-center h-20">
                <div className="w-8 h-8 bg-destructive rounded-full scale-pulse"></div>
                <div className="w-8 h-8 bg-secondary rounded-full pulse-subtle"></div>
                <div className="w-8 h-8 bg-accent rounded-full bounce-soft"></div>
              </div>
            </CardContent>
          </Card>

          {/* Glass Morphism */}
          <Card variant="dashboard" className="glass-card card-interactive">
            <CardHeader>
              <h3 className="text-xl font-semibold">Glass Morphism</h3>
              <p className="text-sm text-muted-foreground">Modern translucent design effects</p>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                This card demonstrates glass morphism with backdrop blur, subtle transparency, 
                and enhanced shadows for a modern, floating appearance.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Staggered Animation Demo */}
        <div className="mt-12">
          <Card variant="dashboard" className="card-interactive">
            <CardHeader>
              <h3 className="text-xl font-semibold text-center">Staggered Animations</h3>
              <p className="text-sm text-muted-foreground text-center">
                Elements appear with sequential delays for smooth entrance effects
              </p>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="h-16 bg-primary/10 rounded-lg flex items-center justify-center text-sm font-medium stagger-1 card-interactive">
                  Item 1
                </div>
                <div className="h-16 bg-secondary/10 rounded-lg flex items-center justify-center text-sm font-medium stagger-2 card-interactive">
                  Item 2
                </div>
                <div className="h-16 bg-accent/20 rounded-lg flex items-center justify-center text-sm font-medium stagger-3 card-interactive">
                  Item 3
                </div>
                <div className="h-16 bg-muted rounded-lg flex items-center justify-center text-sm font-medium stagger-4 card-interactive">
                  Item 4
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default LoadingStates;