import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  AlertTriangle,
  TrendingUp,
  Activity,
  Users,
  Eye,
  MessageSquare,
  Heart,
  Share2,
  MapPin,
  Clock,
  ThermometerSun,
  Wind
} from 'lucide-react';
import dashboardBg from '@/assets/dashboard-bg.jpg';

const Dashboard = () => {
  // Mock data for demonstration
  const recentReports = [
    {
      id: 1,
      type: 'Tsunami Warning',
      location: 'Bay of Bengal',
      severity: 'High',
      time: '2 min ago',
      status: 'Active'
    },
    {
      id: 2,
      type: 'Storm Surge',
      location: 'Arabian Sea',
      severity: 'Medium',
      time: '15 min ago',
      status: 'Monitoring'
    },
    {
      id: 3,
      type: 'High Waves',
      location: 'Tamil Nadu Coast',
      severity: 'Low',
      time: '1 hour ago',
      status: 'Resolved'
    }
  ];

  const socialMetrics = [
    { platform: 'Twitter', mentions: 1247, sentiment: 'Positive', engagement: '+12%' },
    { platform: 'Facebook', mentions: 892, sentiment: 'Neutral', engagement: '+5%' },
    { platform: 'Instagram', mentions: 534, sentiment: 'Positive', engagement: '+18%' }
  ];

  const getSeverityVariant = (severity: string) => {
    switch (severity) {
      case 'High': return 'destructive';
      case 'Medium': return 'secondary';
      case 'Low': return 'outline';
      default: return 'outline';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Active': return 'text-destructive';
      case 'Monitoring': return 'text-warning';
      case 'Resolved': return 'text-accent-dark';
      default: return 'text-muted-foreground';
    }
  };

  return (
    <section className="py-16 bg-muted/30 relative overflow-hidden">
      {/* Background */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-5"
        style={{ backgroundImage: `url(${dashboardBg})` }}
      />
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Real-Time Operations Dashboard
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Monitor ocean hazards, track social media sentiment, and coordinate emergency response 
            through our integrated analytics platform.
          </p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          <Card variant="ocean" className="card-interactive stagger-1">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Active Alerts</p>
                  <p className="text-2xl font-bold text-destructive">23</p>
                </div>
                <AlertTriangle className="h-8 w-8 text-destructive scale-pulse" />
              </div>
              <div className="mt-2 flex items-center">
                <Badge variant="destructive" className="text-xs hover-lift">+5 from yesterday</Badge>
              </div>
            </CardContent>
          </Card>

          <Card variant="ocean" className="card-interactive stagger-2">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Social Mentions</p>
                  <p className="text-2xl font-bold text-secondary">2,673</p>
                </div>
                <MessageSquare className="h-8 w-8 text-secondary gentle-float" />
              </div>
              <div className="mt-2 flex items-center">
                <TrendingUp className="h-3 w-3 text-accent-dark mr-1 bounce-soft" />
                <span className="text-xs text-accent-dark">+12% increase</span>
              </div>
            </CardContent>
          </Card>

          <Card variant="ocean" className="card-interactive stagger-3">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Active Users</p>
                  <p className="text-2xl font-bold text-accent-dark">8,947</p>
                </div>
                <Users className="h-8 w-8 text-accent-dark floating-delayed" />
              </div>
              <div className="mt-2 flex items-center">
                <Activity className="h-3 w-3 text-accent-dark mr-1 rotate-slow" />
                <span className="text-xs text-accent-dark">Live monitoring</span>
              </div>
            </CardContent>
          </Card>

          <Card variant="ocean" className="card-interactive stagger-4">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">System Health</p>
                  <p className="text-2xl font-bold text-accent-dark">99.9%</p>
                </div>
                <Activity className="h-8 w-8 text-accent-dark pulse-subtle" />
              </div>
              <div className="mt-2 flex items-center">
                <div className="h-2 w-2 rounded-full bg-accent-dark mr-2 scale-pulse" />
                <span className="text-xs text-muted-foreground">All systems operational</span>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Recent Reports */}
          <Card variant="dashboard">
            <CardHeader>
              <CardTitle className="flex items-center">
                <AlertTriangle className="mr-2 h-5 w-5 text-destructive" />
                Recent Hazard Reports
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentReports.map((report, index) => (
                  <div key={report.id} className={`flex items-center justify-between p-4 border border-border rounded-lg hover:bg-muted/50 transition-all duration-300 hover-lift stagger-${index + 1}`}>
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <Badge variant={getSeverityVariant(report.severity)} className="hover-glow">
                          {report.severity}
                        </Badge>
                        <span className="text-sm font-medium text-foreground">{report.type}</span>
                      </div>
                      <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                        <div className="flex items-center">
                          <MapPin className="mr-1 h-3 w-3 gentle-float" />
                          {report.location}
                        </div>
                        <div className="flex items-center">
                          <Clock className="mr-1 h-3 w-3 rotate-slow" />
                          {report.time}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className={`text-sm font-medium ${getStatusColor(report.status)} pulse-subtle`}>
                        {report.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-6">
                <Button variant="outline" className="w-full">
                  View All Reports
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Social Media Analytics */}
          <Card variant="dashboard">
            <CardHeader>
              <CardTitle className="flex items-center">
                <TrendingUp className="mr-2 h-5 w-5 text-secondary" />
                Social Media Analytics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {socialMetrics.map((metric, index) => (
                  <div key={index} className="flex items-center justify-between p-4 border border-border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className={`h-3 w-3 rounded-full ${
                        metric.platform === 'Twitter' ? 'bg-blue-500' :
                        metric.platform === 'Facebook' ? 'bg-blue-600' : 'bg-pink-500'
                      }`} />
                      <div>
                        <p className="text-sm font-medium text-foreground">{metric.platform}</p>
                        <p className="text-xs text-muted-foreground">{metric.mentions} mentions</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge variant="outline" className={`mb-1 ${
                        metric.sentiment === 'Positive' ? 'text-accent-dark border-accent-dark' :
                        metric.sentiment === 'Neutral' ? 'text-muted-foreground' : 'text-destructive border-destructive'
                      }`}>
                        {metric.sentiment}
                      </Badge>
                      <p className="text-xs text-accent-dark font-medium">{metric.engagement}</p>
                    </div>
                  </div>
                ))}
              </div>
              
              {/* Quick Actions */}
              <div className="mt-6 grid grid-cols-2 gap-3">
                <Button variant="surface" size="sm" className="w-full">
                  <Eye className="mr-2 h-4 w-4" />
                  View Details
                </Button>
                <Button variant="surface" size="sm" className="w-full">
                  <Share2 className="mr-2 h-4 w-4" />
                  Export Report
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Environmental Conditions */}
        <div className="mt-8">
          <Card variant="dashboard" className="card-interactive">
            <CardHeader>
              <CardTitle className="flex items-center">
                <ThermometerSun className="mr-2 h-5 w-5 text-secondary floating-slow" />
                Current Environmental Conditions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="text-center hover-float">
                  <ThermometerSun className="h-8 w-8 text-secondary mx-auto mb-2 scale-pulse" />
                  <p className="text-2xl font-bold text-foreground">28°C</p>
                  <p className="text-sm text-muted-foreground">Sea Surface Temp</p>
                </div>
                <div className="text-center hover-float">
                  <Wind className="h-8 w-8 text-accent-dark mx-auto mb-2 gentle-float" />
                  <p className="text-2xl font-bold text-foreground">15 km/h</p>
                  <p className="text-sm text-muted-foreground">Wind Speed</p>
                </div>
                <div className="text-center hover-float">
                  <Activity className="h-8 w-8 text-primary mx-auto mb-2 bounce-soft" />
                  <p className="text-2xl font-bold text-foreground">2.1 m</p>
                  <p className="text-sm text-muted-foreground">Wave Height</p>
                </div>
                <div className="text-center hover-float">
                  <TrendingUp className="h-8 w-8 text-destructive mx-auto mb-2 rotate-slow" />
                  <p className="text-2xl font-bold text-foreground">1013 hPa</p>
                  <p className="text-sm text-muted-foreground">Pressure</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default Dashboard;