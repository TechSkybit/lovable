import React from 'react';
import Navigation from '@/components/Navigation';
import Hero from '@/components/Hero';
import Dashboard from '@/components/Dashboard';
import MapView from '@/components/MapView';
import About from '@/components/About';
import LoadingStates from '@/components/LoadingStates';

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main>
        <Hero />
        <Dashboard />
        <MapView />
        <LoadingStates />
        <About />
      </main>
      
      {/* Enhanced Footer */}
      <footer className="border-t border-border bg-ocean-depth relative overflow-hidden">
        {/* Background wave effect */}
        <div className="absolute inset-0 wave-pattern opacity-10"></div>
        
        <div className="relative z-10 container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="flex h-8 w-8 items-center justify-center rounded bg-secondary/20">
                  <div className="h-4 w-4 bg-secondary rounded gentle-float"></div>
                </div>
                <h4 className="text-lg font-semibold text-white">INCOIS</h4>
              </div>
              <p className="text-sm text-white/80">
                Indian National Centre for Ocean Information Services
              </p>
              <p className="text-xs text-white/60">
                Ministry of Earth Sciences, Government of India
              </p>
            </div>
            
            <div className="space-y-3">
              <h5 className="font-medium text-white">Services</h5>
              <div className="space-y-2 text-sm text-white/70">
                <div className="hover:text-white transition-colors cursor-pointer hover-lift">Tsunami Warning</div>
                <div className="hover:text-white transition-colors cursor-pointer hover-lift">Ocean Forecasting</div>
                <div className="hover:text-white transition-colors cursor-pointer hover-lift">Marine Weather</div>
                <div className="hover:text-white transition-colors cursor-pointer hover-lift">Emergency Response</div>
              </div>
            </div>
            
            <div className="space-y-3">
              <h5 className="font-medium text-white">Resources</h5>
              <div className="space-y-2 text-sm text-white/70">
                <div className="hover:text-white transition-colors cursor-pointer hover-lift">Safety Guidelines</div>
                <div className="hover:text-white transition-colors cursor-pointer hover-lift">Educational Materials</div>
                <div className="hover:text-white transition-colors cursor-pointer hover-lift">Research Publications</div>
                <div className="hover:text-white transition-colors cursor-pointer hover-lift">Data Portal</div>
              </div>
            </div>
            
            <div className="space-y-3">
              <h5 className="font-medium text-white">Support</h5>
              <div className="space-y-2 text-sm text-white/70">
                <div className="hover:text-white transition-colors cursor-pointer hover-lift">Emergency Hotline</div>
                <div className="hover:text-white transition-colors cursor-pointer hover-lift">Technical Support</div>
                <div className="hover:text-white transition-colors cursor-pointer hover-lift">Contact Information</div>
                <div className="hover:text-white transition-colors cursor-pointer hover-lift">Feedback</div>
              </div>
            </div>
          </div>
          
          <div className="border-t border-white/20 mt-8 pt-8 text-center">
            <p className="text-sm text-white/60">
              © 2024 Indian National Centre for Ocean Information Services (INCOIS). All rights reserved.
            </p>
            <div className="flex justify-center items-center space-x-2 mt-2">
              <div className="h-2 w-2 rounded-full bg-accent scale-pulse"></div>
              <span className="text-xs text-white/50">System Status: Operational</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
